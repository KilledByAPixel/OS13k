x.fillRect(0,0,c.width|=0,2e3)
for(i=0;++i<32;x.fill())x.arc(960,540,1e4*OS13k.GetAnalyserData(x.beginPath(x.fillStyle=`hsl(${i*7-120},99%,50%,.1)`))[i]/(i+9),0,7)